/*
  # Add Products and Payment Integration

  1. New Tables
    - `payment_methods` for storing payment configurations
    - Add new products across multiple categories
  
  2. Changes
    - Add payment_method column to orders table
    - Insert new product data
*/

-- Add payment method to orders
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_method text;

-- Create payment methods table
CREATE TABLE IF NOT EXISTS payment_methods (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  type text NOT NULL,
  enabled boolean DEFAULT true,
  config jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;

-- Payment methods are viewable by everyone
CREATE POLICY "Payment methods are viewable by everyone"
  ON payment_methods FOR SELECT
  TO authenticated, anon
  USING (enabled = true);

-- Insert payment methods
INSERT INTO payment_methods (name, type, config) VALUES
  ('Paytm', 'paytm', '{"merchant_id": "your_merchant_id", "merchant_key": "your_merchant_key"}'::jsonb);

-- Insert new products
INSERT INTO products (name, description, price, image_url, stock_quantity, rating, review_count) VALUES
  -- Crockery
  ('Ceramic Dinner Set', 'Premium 24-piece ceramic dinner set with elegant design', 89.99, 'https://images.unsplash.com/photo-1603199506016-b9a594b593c0?auto=format&fit=crop&q=80&w=800', 30, 4.6, 75),
  ('Glass Serving Bowl', 'Large crystal clear glass serving bowl', 34.99, 'https://images.unsplash.com/photo-1610701596007-11502861dcfa?auto=format&fit=crop&q=80&w=800', 50, 4.4, 45),
  
  -- Furniture
  ('Modern Sofa Set', 'Contemporary 3-seater sofa with premium fabric', 899.99, 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&q=80&w=800', 10, 4.7, 28),
  ('Coffee Table', 'Wooden coffee table with storage', 199.99, 'https://images.unsplash.com/photo-1533090481720-856c6e3c1fdc?auto=format&fit=crop&q=80&w=800', 15, 4.5, 34),
  
  -- Curtains
  ('Blackout Curtains', 'Thermal insulated blackout curtains, set of 2', 49.99, 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=800', 100, 4.3, 156),
  
  -- Laptops
  ('HP Pavilion', 'HP Pavilion 15.6" Laptop, 16GB RAM, 512GB SSD', 899.99, 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&q=80&w=800', 20, 4.5, 89),
  ('Dell XPS 13', 'Dell XPS 13 with 4K display, 16GB RAM', 1299.99, 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?auto=format&fit=crop&q=80&w=800', 15, 4.8, 67),
  ('MacBook Pro', 'MacBook Pro 14" with M2 chip', 1999.99, 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=800', 10, 4.9, 92),
  
  -- Smartphones
  ('Realme GT', 'Realme GT 5G, 8GB RAM, 128GB Storage', 399.99, 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&q=80&w=800', 30, 4.4, 156),
  ('Redmi Note 12', 'Redmi Note 12 Pro, 6GB RAM, 128GB Storage', 299.99, 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&q=80&w=800', 40, 4.3, 234),
  ('Samsung S23', 'Samsung Galaxy S23 Ultra, 12GB RAM', 1199.99, 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&q=80&w=800', 25, 4.7, 189),
  ('iPhone 15', 'iPhone 15 Pro Max, 256GB Storage', 1299.99, 'https://images.unsplash.com/photo-1696446701796-da61225697cc?auto=format&fit=crop&q=80&w=800', 20, 4.8, 245),
  
  -- Chocolates
  ('KitKat Pack', 'Pack of 12 KitKat chocolate bars', 9.99, 'https://images.unsplash.com/photo-1621939514649-280e2ee25f60?auto=format&fit=crop&q=80&w=800', 200, 4.6, 567),
  ('Dairy Milk', 'Cadbury Dairy Milk chocolate bar, 150g', 4.99, 'https://images.unsplash.com/photo-1623341214825-9f4f963727da?auto=format&fit=crop&q=80&w=800', 300, 4.7, 789),
  ('Ferrero Rocher', 'Ferrero Rocher 24 pieces gift box', 24.99, 'https://images.unsplash.com/photo-1548907040-4d42b3018e22?auto=format&fit=crop&q=80&w=800', 150, 4.9, 345),
  
  -- Electronics
  ('Electric Kettle', 'Stainless steel electric kettle, 1.7L', 39.99, 'https://images.unsplash.com/photo-1594213114663-d94db9b17612?auto=format&fit=crop&q=80&w=800', 50, 4.4, 123),
  ('Smart TV 55"', '55" 4K Smart LED TV with HDR', 699.99, 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&q=80&w=800', 15, 4.6, 78),
  ('Hair Trimmer', 'Professional hair trimmer with accessories', 49.99, 'https://images.unsplash.com/photo-1621607512214-68297480165e?auto=format&fit=crop&q=80&w=800', 40, 4.5, 234);