import React from 'react';
import { LogOut, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface UserMenuProps {
  onSignInClick: () => void;
}

export const UserMenu: React.FC<UserMenuProps> = ({ onSignInClick }) => {
  const { user, signOut } = useAuth();

  if (!user) {
    return (
      <button
        onClick={onSignInClick}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
      >
        <User size={24} />
        <span>Sign In</span>
      </button>
    );
  }

  return (
    <div className="relative group">
      <button className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
        {user.avatar_url ? (
          <img
            src={user.avatar_url}
            alt={user.full_name || user.email}
            className="w-8 h-8 rounded-full"
          />
        ) : (
          <User size={24} />
        )}
        <span>{user.full_name || user.email}</span>
      </button>
      <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block">
        <button
          onClick={() => signOut()}
          className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full"
        >
          <LogOut size={16} />
          Sign Out
        </button>
      </div>
    </div>
  );
};