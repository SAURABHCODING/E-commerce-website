import React, { useState } from 'react';
import { PaytmPayment } from '../lib/paytm';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

interface PaymentFormProps {
  orderId: string;
  amount: number;
  onSuccess: () => void;
  onError: (error: Error) => void;
}

export const PaymentForm: React.FC<PaymentFormProps> = ({
  orderId,
  amount,
  onSuccess,
  onError,
}) => {
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const paytm = new PaytmPayment();

  const handlePayment = async () => {
    if (!user) {
      toast.error('Please sign in to continue');
      return;
    }

    setLoading(true);
    try {
      const params = await paytm.initiatePayment(orderId, amount, user.id);
      
      // In a real implementation, this would create and submit a form to Paytm
      console.log('Payment initiated with params:', params);
      
      // Simulate successful payment for demo
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast.success('Payment successful!');
      onSuccess();
    } catch (error) {
      console.error('Payment failed:', error);
      onError(error as Error);
      toast.error('Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-6">
      <button
        onClick={handlePayment}
        disabled={loading}
        className={`w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors ${
          loading ? 'opacity-50 cursor-not-allowed' : ''
        }`}
      >
        {loading ? 'Processing...' : 'Pay with Paytm'}
      </button>
      <p className="mt-2 text-sm text-gray-600 text-center">
        Secure payment powered by Paytm
      </p>
    </div>
  );
};