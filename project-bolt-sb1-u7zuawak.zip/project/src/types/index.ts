export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  rating?: number;
  reviews?: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
}

export interface WishlistItem {
  product_id: string;
  user_id: string;
  created_at: string;
}