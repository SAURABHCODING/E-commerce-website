import React, { useState, useEffect } from 'react';
import { ShoppingCart as CartIcon, Sun, Moon } from 'lucide-react';
import { CartProvider } from './context/CartContext';
import { AuthProvider } from './context/AuthContext';
import { ProductCard } from './components/ProductCard';
import { Cart } from './components/Cart';
import { AuthModal } from './components/AuthModal';
import { UserMenu } from './components/UserMenu';
import { Product } from './types';
import { Toaster } from 'react-hot-toast';
import { useCart } from './context/CartContext';

// Sample products data
const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Headphones',
    price: 199.99,
    description: 'Premium noise-canceling wireless headphones with superior sound quality.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=800',
    rating: 4.5,
    reviews: 128,
  },
  {
    id: '2',
    name: 'Smart Watch',
    price: 299.99,
    description: 'Feature-rich smartwatch with health tracking and notifications.',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviews: 256,
  },
  {
    id: '3',
    name: 'Laptop Backpack',
    price: 79.99,
    description: 'Durable and water-resistant backpack with laptop compartment.',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&q=80&w=800',
    rating: 4.2,
    reviews: 89,
  },
  {
    id: '4',
    name: 'iPhone 15',
    price: 1299.99,
    description: 'iPhone 15 Pro Max, 256GB Storage',
    image: 'https://images.unsplash.com/photo-1696446701796-da61225697cc?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviews: 245,
  },
  {
    id: '5',
    name: 'Dairy Milk',
    price: 4.99,
    description: 'Cadbury Dairy Milk chocolate bar, 150g',
    image: 'https://images.unsplash.com/photo-1623341214825-9f4f963727da?auto=format&fit=crop&q=80&w=800',
    rating: 4.7,
    reviews: 789,
  },
  {
    id: '6',
    name: 'Ferrero Rocher',
    price: 24.99,
    description: 'Ferrero Rocher 24 pieces gift box',
    image: 'https://images.unsplash.com/photo-1548907040-4d42b3018e22?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviews: 345,
  },
];

function AppContent() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const { dispatch } = useCart();

  // Add selected products to cart on component mount
  useEffect(() => {
    const productsToAdd = ['4', '5', '6']; // IDs of iPhone 15, Dairy Milk, and Ferrero Rocher
    productsToAdd.forEach(id => {
      const product = products.find(p => p.id === id);
      if (product) {
        dispatch({ type: 'ADD_ITEM', payload: product });
      }
    });
    setIsCartOpen(true); // Open the cart automatically
  }, [dispatch]);

  // Apply dark mode to the root element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-100'}`}>
      {/* Navigation */}
      <nav className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              MyStore
            </h1>
            <div className="flex items-center gap-6">
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className={`p-2 ${isDarkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900'}`}
              >
                {isDarkMode ? <Sun size={24} /> : <Moon size={24} />}
              </button>
              <UserMenu onSignInClick={() => setIsAuthModalOpen(true)} />
              <button
                onClick={() => setIsCartOpen(!isCartOpen)}
                className={`relative p-2 ${
                  isDarkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <CartIcon size={24} />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Products Grid */}
          <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 ${isCartOpen ? 'w-2/3' : 'w-full'}`}>
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {/* Cart Sidebar */}
          {isCartOpen && (
            <div className="w-1/3">
              <Cart />
            </div>
          )}
        </div>
      </main>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* Toast Notifications */}
      <Toaster position="top-right" />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </AuthProvider>
  );
}

export default App;